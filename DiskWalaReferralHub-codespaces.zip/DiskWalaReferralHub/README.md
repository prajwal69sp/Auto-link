# DiskWala Referral Hub

Kotlin + Jetpack Compose (Material 3) app for sharing a DiskWala referral link.

## GitHub Codespaces
1. Create a new GitHub repo and upload/push the contents of this folder (the `.devcontainer` folder must be at the repo root).
2. Click **Code → Codespaces → Create codespace on main**. First start takes a few minutes: it installs JDK 17, Gradle and the Android SDK, and generates `gradlew`.
3. In the terminal run `bash build.sh`.
4. Right-click `app/build/outputs/apk/debug/app-debug.apk` in the Explorer → **Download**, then install it on your phone (allow "install unknown apps").

Codespaces has no emulator, so test on a real device. The included GitHub Actions workflow (`.github/workflows/build.yml`) also builds the APK on every push; download it from the run's **Artifacts**.

## Android Studio
Open the folder in Android Studio (Ladybug or newer, JDK 17), let Gradle sync, then Run.

Before publishing:
1. Replace `SUPPORT_EMAIL` in `core/config/ReferralConfig.kt`.
2. Have the policy text in `ui/safety/LegalContent.kt` reviewed and confirm DiskWala's current referral/affiliate terms.
3. If DiskWala ever offers an official API, implement it as a new `ReferralStatsRepository`
   (see the comment in `data/UnavailableReferralStatsRepository.kt`).

Layers: `core` (config, utils) · `domain` (models, repository interface, use case) ·
`data` (repository implementations) · `ui` (theme, components, screens).
