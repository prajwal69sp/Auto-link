#!/usr/bin/env bash
# Runs once when the Codespace is created: installs the Android SDK and the Gradle wrapper.
set -euo pipefail

export ANDROID_HOME="$HOME/android-sdk"
CMDLINE_ZIP="commandlinetools-linux-11076708_latest.zip"

sudo apt-get update -y && sudo apt-get install -y unzip curl

mkdir -p "$ANDROID_HOME/cmdline-tools"
if [ ! -x "$ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager" ]; then
  curl -fsSL -o "/tmp/$CMDLINE_ZIP" "https://dl.google.com/android/repository/$CMDLINE_ZIP"
  unzip -q "/tmp/$CMDLINE_ZIP" -d "$ANDROID_HOME/cmdline-tools"
  mv "$ANDROID_HOME/cmdline-tools/cmdline-tools" "$ANDROID_HOME/cmdline-tools/latest"
  rm "/tmp/$CMDLINE_ZIP"
fi

SDKM="$ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager"
yes | "$SDKM" --licenses > /dev/null || true
"$SDKM" "platform-tools" "platforms;android-35" "build-tools;35.0.0"

# Make the SDK visible to every future terminal and to Gradle.
{
  echo "export ANDROID_HOME=\"$ANDROID_HOME\""
  echo "export ANDROID_SDK_ROOT=\"$ANDROID_HOME\""
  echo "export PATH=\"\$PATH:$ANDROID_HOME/platform-tools:$ANDROID_HOME/cmdline-tools/latest/bin\""
} >> "$HOME/.bashrc"
echo "sdk.dir=$ANDROID_HOME" > local.properties

# Generate gradlew + wrapper jar (not shipped in the zip).
gradle wrapper --gradle-version 8.9 --distribution-type bin

echo "Setup complete. Build with:  bash build.sh"
