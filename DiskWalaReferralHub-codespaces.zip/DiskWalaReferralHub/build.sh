#!/usr/bin/env bash
# Builds the debug APK and prints where it is.
set -euo pipefail
export ANDROID_HOME="${ANDROID_HOME:-$HOME/android-sdk}"
[ -f local.properties ] || echo "sdk.dir=$ANDROID_HOME" > local.properties

if [ -x ./gradlew ]; then ./gradlew assembleDebug --no-daemon; else gradle assembleDebug --no-daemon; fi

echo
echo "APK: app/build/outputs/apk/debug/app-debug.apk"
echo "Download: right-click the file in the Explorer panel -> Download"
